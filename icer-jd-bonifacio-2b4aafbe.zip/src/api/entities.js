import { base44 } from './base44Client';


export const BibleVerse = base44.entities.BibleVerse;

export const QuizQuestion = base44.entities.QuizQuestion;

export const UserScore = base44.entities.UserScore;

export const Event = base44.entities.Event;

export const QuizSettings = base44.entities.QuizSettings;



// auth sdk:
export const User = base44.auth;