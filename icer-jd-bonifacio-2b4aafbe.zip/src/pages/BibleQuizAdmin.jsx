
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Separator } from "@/components/ui/separator";
import { 
  ArrowLeft, 
  CheckCircle2, 
  XCircle, 
  Plus,
  Edit,
  Trash2,
  Filter,
  BookOpen,
  Save,
  RefreshCw,
  AlertCircle
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { QuizQuestion } from "@/api/entities";
import { User } from "@/api/entities";
import { QuizSettings } from "@/api/entities"; // Importing QuizSettings entity
import { UserScore } from "@/api/entities";

export default function BibleQuizAdmin() {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [questions, setQuestions] = useState([]);
  const [filteredQuestions, setFilteredQuestions] = useState([]);
  const [activeTab, setActiveTab] = useState("todas");
  const [selectedDifficulty, setSelectedDifficulty] = useState("todas");
  const [selectedBook, setSelectedBook] = useState("todos");
  const [enabledBooks, setEnabledBooks] = useState([]);
  const [userSettings, setUserSettings] = useState(null);
  
  const [formData, setFormData] = useState({
    question: "",
    options: ["", "", "", ""],
    correctOptionIndex: 0,
    difficulty: "médio",
    reference: "",
    biblicalBook: "",
    active: true
  });
  const [editingQuestionId, setEditingQuestionId] = useState(null);
  
  const biblicalBooks = [
    "Gênesis", "Êxodo", "Levítico", "Números", "Deuteronômio", "Josué", "Juízes", "Rute", 
    "1 Samuel", "2 Samuel", "1 Reis", "2 Reis", "1 Crônicas", "2 Crônicas", "Esdras", 
    "Neemias", "Ester", "Jó", "Salmos", "Provérbios", "Eclesiastes", "Cânticos", "Isaías", 
    "Jeremias", "Lamentações", "Ezequiel", "Daniel", "Oséias", "Joel", "Amós", "Obadias", 
    "Jonas", "Miquéias", "Naum", "Habacuque", "Sofonias", "Ageu", "Zacarias", "Malaquias",
    "Mateus", "Marcos", "Lucas", "João", "Atos", "Romanos", "1 Coríntios", "2 Coríntios", 
    "Gálatas", "Efésios", "Filipenses", "Colossenses", "1 Tessalonicenses", "2 Tessalonicenses", 
    "1 Timóteo", "2 Timóteo", "Tito", "Filemom", "Hebreus", "Tiago", "1 Pedro", "2 Pedro", 
    "1 João", "2 João", "3 João", "Judas", "Apocalipse"
  ];

  useEffect(() => {
    async function fetchData() {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
        setIsAdmin(currentUser.role === 'admin');
        
        if (currentUser.role !== 'admin') {
          return;
        }
        
        const allQuestions = await QuizQuestion.list();
        setQuestions(allQuestions);
        setFilteredQuestions(allQuestions);
        
        setEnabledBooks(biblicalBooks);
      } catch (error) {
        console.error("Erro ao verificar usuário:", error);
        setIsAdmin(false);
      } finally {
        setLoading(false);
      }
    }
    
    fetchData();
  }, []);

  useEffect(() => {
    let filtered = [...questions];
    
    if (selectedDifficulty !== "todas") {
      filtered = filtered.filter(q => q.difficulty === selectedDifficulty);
    }
    
    if (selectedBook !== "todos") {
      filtered = filtered.filter(q => q.biblicalBook === selectedBook);
    }
    
    if (activeTab !== "todas") {
      filtered = filtered.filter(q => 
        activeTab === "ativas" ? q.active : !q.active
      );
    }
    
    setFilteredQuestions(filtered);
  }, [questions, selectedDifficulty, selectedBook, activeTab]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleOptionChange = (index, value) => {
    const newOptions = [...formData.options];
    newOptions[index] = value;
    setFormData({
      ...formData,
      options: newOptions
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setLoading(true);
      
      if (editingQuestionId) {
        await QuizQuestion.update(editingQuestionId, formData);
      } else {
        await QuizQuestion.create(formData);
      }
      
      setFormData({
        question: "",
        options: ["", "", "", ""],
        correctOptionIndex: 0,
        difficulty: "médio",
        reference: "",
        biblicalBook: "",
        active: true
      });
      setEditingQuestionId(null);
      
      const allQuestions = await QuizQuestion.list();
      setQuestions(allQuestions);
      
    } catch (error) {
      console.error("Erro ao salvar pergunta:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (question) => {
    setFormData({
      question: question.question,
      options: question.options,
      correctOptionIndex: question.correctOptionIndex,
      difficulty: question.difficulty,
      reference: question.reference || "",
      biblicalBook: question.biblicalBook || "",
      active: question.active
    });
    setEditingQuestionId(question.id);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Tem certeza que deseja excluir esta pergunta?")) {
      try {
        setLoading(true);
        await QuizQuestion.delete(id);
        
        const allQuestions = await QuizQuestion.list();
        setQuestions(allQuestions);
      } catch (error) {
        console.error("Erro ao excluir pergunta:", error);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleToggleActive = async (question) => {
    try {
      await QuizQuestion.update(question.id, { 
        ...question, 
        active: !question.active 
      });
      
      const allQuestions = await QuizQuestion.list();
      setQuestions(allQuestions);
    } catch (error) {
      console.error("Erro ao atualizar status da pergunta:", error);
    }
  };

  const toggleBookEnabled = (book) => {
    const newEnabledBooks = enabledBooks.includes(book)
      ? enabledBooks.filter(b => b !== book)
      : [...enabledBooks, book];
    
    setEnabledBooks(newEnabledBooks);
  };

  const saveBookSettings = async () => {
    try {
      setLoading(true);
      alert("Configurações aplicadas localmente. A funcionalidade de salvar será implementada em breve.");
      setLoading(false);
    } catch (error) {
      console.error("Erro ao salvar configurações:", error);
      setLoading(false);
    }
  };

  const oldTestament = biblicalBooks.slice(0, 39);
  const newTestament = biblicalBooks.slice(39);

  return (
    <div className="space-y-6">
      {!isAdmin ? (
        <Card className="bg-gray-900/90 border border-white/10 shadow-[0_0_30px_rgba(255,255,255,0.05)]">
          <CardContent className="p-10 flex flex-col items-center justify-center">
            <AlertCircle className="text-red-400 w-16 h-16 mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">Acesso Restrito</h2>
            <p className="text-white/60 text-center">Esta área é destinada apenas a administradores.</p>
            <Link to={createPageUrl("Home")}>
              <Button className="mt-6">
                Voltar para Home
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <Tabs defaultValue="perguntas" className="w-full">
          <TabsList className="grid grid-cols-2 mb-6">
            <TabsTrigger value="perguntas">Perguntas</TabsTrigger>
            <TabsTrigger value="configuracoes">Configurações</TabsTrigger>
          </TabsList>
          
          <TabsContent value="perguntas" className="space-y-6">
            <Card className="bg-gray-900/90 border border-white/10 shadow-[0_0_30px_rgba(255,255,255,0.05)]">
              <CardHeader className="border-b border-white/10">
                <CardTitle className="text-white">Nova Pergunta</CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="question" className="text-white">Pergunta</Label>
                    <Textarea 
                      id="question"
                      name="question"
                      value={formData.question}
                      onChange={handleInputChange}
                      placeholder="Digite a pergunta"
                      required
                      className="bg-gray-800 border-white/10 text-white"
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-white">Opções (a correta é destacada)</Label>
                      {formData.options.map((option, index) => (
                        <div key={index} className="flex items-center gap-2 mt-2">
                          <Checkbox 
                            checked={formData.correctOptionIndex === index}
                            onCheckedChange={() => setFormData({...formData, correctOptionIndex: index})}
                          />
                          <Input 
                            value={option}
                            onChange={(e) => handleOptionChange(index, e.target.value)}
                            placeholder={`Opção ${index + 1}`}
                            className={`bg-gray-800 border-white/10 text-white ${formData.correctOptionIndex === index ? 'border-green-500' : ''}`}
                            required
                          />
                        </div>
                      ))}
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="difficulty" className="text-white">Dificuldade</Label>
                        <Select 
                          value={formData.difficulty} 
                          onValueChange={(value) => setFormData({...formData, difficulty: value})}
                        >
                          <SelectTrigger className="bg-gray-800 border-white/10 text-white">
                            <SelectValue placeholder="Selecione a dificuldade" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="fácil">Fácil</SelectItem>
                            <SelectItem value="médio">Médio</SelectItem>
                            <SelectItem value="difícil">Difícil</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label htmlFor="biblicalBook" className="text-white">Livro Bíblico</Label>
                        <Select 
                          value={formData.biblicalBook} 
                          onValueChange={(value) => setFormData({...formData, biblicalBook: value})}
                        >
                          <SelectTrigger className="bg-gray-800 border-white/10 text-white">
                            <SelectValue placeholder="Selecione o livro" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value={null}>-- Selecione --</SelectItem>
                            {biblicalBooks.map(book => (
                              <SelectItem key={book} value={book}>{book}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label htmlFor="reference" className="text-white">Referência Bíblica</Label>
                        <Input 
                          id="reference"
                          name="reference"
                          value={formData.reference}
                          onChange={handleInputChange}
                          placeholder="Ex: João 3:16"
                          className="bg-gray-800 border-white/10 text-white"
                        />
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Checkbox 
                          id="active"
                          checked={formData.active}
                          onCheckedChange={(checked) => setFormData({...formData, active: checked})}
                        />
                        <Label htmlFor="active" className="text-white">Pergunta ativa</Label>
                      </div>
                    </div>
                  </div>
                  
                  <Button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white">
                    {editingQuestionId ? (
                      <>
                        <Save className="w-4 h-4 mr-2" />
                        Atualizar Pergunta
                      </>
                    ) : (
                      <>
                        <Plus className="w-4 h-4 mr-2" />
                        Adicionar Pergunta
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900/90 border border-white/10 shadow-[0_0_30px_rgba(255,255,255,0.05)]">
              <CardHeader className="border-b border-white/10">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-white">Lista de Perguntas</CardTitle>
                  <div className="flex gap-2">
                    <Select 
                      value={selectedDifficulty} 
                      onValueChange={setSelectedDifficulty}
                    >
                      <SelectTrigger className="w-[150px] bg-gray-800 border-white/10 text-white">
                        <SelectValue placeholder="Dificuldade" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todas">Todas Dificuldades</SelectItem>
                        <SelectItem value="fácil">Fácil</SelectItem>
                        <SelectItem value="médio">Médio</SelectItem>
                        <SelectItem value="difícil">Difícil</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Select 
                      value={selectedBook} 
                      onValueChange={setSelectedBook}
                    >
                      <SelectTrigger className="w-[180px] bg-gray-800 border-white/10 text-white">
                        <SelectValue placeholder="Livro Bíblico" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todos">Todos os Livros</SelectItem>
                        {biblicalBooks.map(book => (
                          <SelectItem key={book} value={book}>{book}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="flex gap-2 mt-4">
                  <Button 
                    variant={activeTab === "todas" ? "default" : "outline"} 
                    onClick={() => setActiveTab("todas")}
                    className={activeTab === "todas" ? "bg-indigo-600 hover:bg-indigo-700" : "text-white"}
                  >
                    Todas ({questions.length})
                  </Button>
                  <Button 
                    variant={activeTab === "ativas" ? "default" : "outline"}
                    onClick={() => setActiveTab("ativas")}
                    className={activeTab === "ativas" ? "bg-green-600 hover:bg-green-700" : "text-white"}
                  >
                    Ativas ({questions.filter(q => q.active).length})
                  </Button>
                  <Button 
                    variant={activeTab === "inativas" ? "default" : "outline"}
                    onClick={() => setActiveTab("inativas")}
                    className={activeTab === "inativas" ? "bg-red-600 hover:bg-red-700" : "text-white"}
                  >
                    Inativas ({questions.filter(q => !q.active).length})
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[400px]">
                  <Table>
                    <TableHeader className="bg-gray-800/50">
                      <TableRow>
                        <TableHead className="text-white">Pergunta</TableHead>
                        <TableHead className="text-white w-24">Dificuldade</TableHead>
                        <TableHead className="text-white w-32">Livro</TableHead>
                        <TableHead className="text-white w-32">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredQuestions.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center text-white/60 py-8">
                            Nenhuma pergunta encontrada com os filtros atuais
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredQuestions.map((question) => (
                          <TableRow 
                            key={question.id}
                            className={`border-b border-white/5 ${!question.active ? 'bg-red-950/20' : ''}`}
                          >
                            <TableCell className="text-white/80">
                              <div>
                                <p>{question.question}</p>
                                <div className="mt-1 text-xs text-white/60">
                                  {question.reference && <span>Ref: {question.reference}</span>}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge className={`
                                ${question.difficulty === 'fácil' ? 'bg-green-600' : 
                                  question.difficulty === 'médio' ? 'bg-yellow-600' : 
                                  'bg-red-600'} text-white`}
                              >
                                {question.difficulty}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-white/70">
                              {question.biblicalBook || "-"}
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleToggleActive(question)}
                                  title={question.active ? "Desativar" : "Ativar"}
                                >
                                  {question.active ? (
                                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                                  ) : (
                                    <XCircle className="h-5 w-5 text-red-500" />
                                  )}
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleEdit(question)}
                                  title="Editar"
                                >
                                  <Edit className="h-5 w-5 text-indigo-400" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleDelete(question.id)}
                                  title="Excluir"
                                >
                                  <Trash2 className="h-5 w-5 text-red-400" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="configuracoes" className="space-y-6">
            <Card className="bg-gray-900/90 border border-white/10 shadow-[0_0_30px_rgba(255,255,255,0.05)]">
              <CardHeader className="border-b border-white/10">
                <CardTitle className="text-white flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  Livros Bíblicos Habilitados para o Quiz
                </CardTitle>
                <p className="text-white/60 text-sm">
                  Selecione quais livros da Bíblia devem ser incluídos no Quiz para os usuários
                </p>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-white font-medium mb-3">Antigo Testamento</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {oldTestament.map(book => (
                        <div key={book} className="flex items-center space-x-2">
                          <Checkbox 
                            id={`book-${book}`}
                            checked={enabledBooks.includes(book)}
                            onCheckedChange={() => toggleBookEnabled(book)}
                          />
                          <Label 
                            htmlFor={`book-${book}`}
                            className="text-sm text-white/80 cursor-pointer hover:text-white"
                          >
                            {book}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-white font-medium mb-3">Novo Testamento</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {newTestament.map(book => (
                        <div key={book} className="flex items-center space-x-2">
                          <Checkbox 
                            id={`book-${book}`}
                            checked={enabledBooks.includes(book)}
                            onCheckedChange={() => toggleBookEnabled(book)}
                          />
                          <Label 
                            htmlFor={`book-${book}`}
                            className="text-sm text-white/80 cursor-pointer hover:text-white"
                          >
                            {book}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-between mt-8">
                  <Button 
                    variant="outline" 
                    onClick={() => setEnabledBooks([...biblicalBooks])}
                    className="text-white"
                  >
                    Selecionar Todos
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => setEnabledBooks([])}
                    className="text-white"
                  >
                    Desmarcar Todos
                  </Button>
                  <Button 
                    onClick={saveBookSettings}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Salvar Configurações
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
