import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  ArrowLeft, 
  Calendar as CalendarIcon,
  Plus,
  Edit,
  Trash2,
  Save,
  Maximize2,
  CheckCircle,
  XCircle,
  AlertCircle
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { BibleVerse } from "@/api/entities";
import { User } from "@/api/entities";

export default function DailyWordAdmin() {
  const [verses, setVerses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    text: "",
    reference: "",
    date: new Date(),
    active: true
  });
  const [editingVerseId, setEditingVerseId] = useState(null);
  const [fullscreenVerse, setFullscreenVerse] = useState(null);

  useEffect(() => {
    async function loadData() {
      try {
        const user = await User.me();
        setIsAdmin(user.role === 'admin');
        
        if (user.role !== 'admin') {
          return;
        }
        
        const fetchedVerses = await BibleVerse.list('-date');
        setVerses(fetchedVerses);
      } catch (error) {
        console.error("Erro ao carregar dados:", error);
        setIsAdmin(false);
      } finally {
        setLoading(false);
      }
    }
    
    loadData();
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      if (editingVerseId) {
        await BibleVerse.update(editingVerseId, formData);
      } else {
        await BibleVerse.create(formData);
      }
      
      setFormData({
        text: "",
        reference: "",
        date: new Date(),
        active: true
      });
      setEditingVerseId(null);
      setShowForm(false);
      
      const fetchedVerses = await BibleVerse.list('-date');
      setVerses(fetchedVerses);
    } catch (error) {
      console.error("Erro ao salvar versículo:", error);
      alert("Erro ao salvar versículo. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (verse) => {
    setFormData({
      text: verse.text,
      reference: verse.reference,
      date: new Date(verse.date),
      active: verse.active
    });
    setEditingVerseId(verse.id);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Tem certeza que deseja excluir este versículo?")) {
      try {
        setLoading(true);
        await BibleVerse.delete(id);
        
        const fetchedVerses = await BibleVerse.list('-date');
        setVerses(fetchedVerses);
      } catch (error) {
        console.error("Erro ao excluir versículo:", error);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleToggleActive = async (verse) => {
    try {
      setLoading(true);
      await BibleVerse.update(verse.id, { ...verse, active: !verse.active });
      
      const fetchedVerses = await BibleVerse.list('-date');
      setVerses(fetchedVerses);
    } catch (error) {
      console.error("Erro ao atualizar status do versículo:", error);
    } finally {
      setLoading(false);
    }
  };

  const enterFullscreen = (verse) => {
    setFullscreenVerse(verse);
    
    const element = document.documentElement;
    if (element.requestFullscreen) {
      element.requestFullscreen();
    } else if (element.mozRequestFullScreen) {
      element.mozRequestFullScreen();
    } else if (element.webkitRequestFullscreen) {
      element.webkitRequestFullscreen();
    } else if (element.msRequestFullscreen) {
      element.msRequestFullscreen();
    }
  };

  const exitFullscreen = () => {
    setFullscreenVerse(null);
    
    if (document.exitFullscreen) {
      document.exitFullscreen();
    } else if (document.mozCancelFullScreen) {
      document.mozCancelFullScreen();
    } else if (document.webkitExitFullscreen) {
      document.webkitExitFullscreen();
    } else if (document.msExitFullscreen) {
      document.msExitFullscreen();
    }
  };

  if (fullscreenVerse) {
    return (
      <div className="fixed inset-0 bg-black flex flex-col items-center justify-center p-10 z-50">
        <div className="max-w-4xl w-full text-center space-y-8">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-8">Palavra do Dia</h1>
          <p className="text-4xl md:text-6xl text-white font-light leading-tight">
            "{fullscreenVerse.text}"
          </p>
          <p className="text-2xl md:text-3xl text-white/80 mt-8 font-semibold">
            {fullscreenVerse.reference}
          </p>
        </div>
        <Button 
          onClick={exitFullscreen} 
          className="absolute bottom-10 right-10 bg-white/10 hover:bg-white/20"
        >
          Sair do modo de tela cheia
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {!isAdmin ? (
        <Card className="bg-gray-900/90 border border-white/10 shadow-[0_0_30px_rgba(255,255,255,0.05)]">
          <CardContent className="p-10 flex flex-col items-center justify-center">
            <AlertCircle className="text-red-400 w-16 h-16 mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">Acesso Restrito</h2>
            <p className="text-white/60 text-center">Esta área é destinada apenas a administradores.</p>
            <Link to={createPageUrl("Home")}>
              <Button className="mt-6">
                Voltar para Home
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="flex justify-between items-center">
            <Link to={createPageUrl("DailyWord")}>
              <Button variant="ghost" className="mb-4 text-white/80 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" /> Voltar para Palavra do Dia
              </Button>
            </Link>
            <h1 className="text-3xl font-bold text-white">Administrar Palavra do Dia</h1>
            <Button 
              onClick={() => {
                setShowForm(!showForm);
                if (!showForm) {
                  setFormData({
                    text: "",
                    reference: "",
                    date: new Date(),
                    active: true
                  });
                  setEditingVerseId(null);
                }
              }}
              className="bg-indigo-600 hover:bg-indigo-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Versículo
            </Button>
          </div>

          {showForm && (
            <Card className="bg-gray-900/90 border border-white/10">
              <CardHeader>
                <CardTitle className="text-white">
                  {editingVerseId ? "Editar Versículo" : "Adicionar Novo Versículo"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="text" className="text-white">Texto do Versículo</Label>
                    <Textarea
                      id="text"
                      name="text"
                      value={formData.text}
                      onChange={handleChange}
                      placeholder="Digite o texto do versículo"
                      className="bg-gray-800 border-white/10 text-white"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="reference" className="text-white">Referência</Label>
                    <Input
                      id="reference"
                      name="reference"
                      value={formData.reference}
                      onChange={handleChange}
                      placeholder="Ex: João 3:16"
                      className="bg-gray-800 border-white/10 text-white"
                      required
                    />
                  </div>

                  <div>
                    <Label className="text-white">Data de Exibição</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full bg-gray-800 border-white/10 text-white justify-start"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {formData.date ? format(new Date(formData.date), 'PPP') : 'Selecione a data'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={formData.date}
                          onSelect={(date) => setFormData({...formData, date})}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="active"
                      name="active"
                      checked={formData.active}
                      onCheckedChange={(checked) => setFormData({...formData, active: checked})}
                    />
                    <Label htmlFor="active" className="text-white">Versículo ativo para exibição</Label>
                  </div>

                  <Button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white">
                    <Save className="w-4 h-4 mr-2" />
                    {editingVerseId ? "Atualizar Versículo" : "Salvar Versículo"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          )}

          <Card className="bg-gray-900/90 border border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Versículos Cadastrados</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-800/50">
                    <TableRow>
                      <TableHead className="text-white">Data</TableHead>
                      <TableHead className="text-white">Referência</TableHead>
                      <TableHead className="text-white">Texto</TableHead>
                      <TableHead className="text-white">Status</TableHead>
                      <TableHead className="text-white text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {verses.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-white/60 py-8">
                          Nenhum versículo cadastrado.
                        </TableCell>
                      </TableRow>
                    ) : (
                      verses.map((verse) => (
                        <TableRow key={verse.id} className="border-b border-white/5">
                          <TableCell className="text-white/80">
                            {format(new Date(verse.date), 'dd/MM/yyyy')}
                          </TableCell>
                          <TableCell className="text-white/80">{verse.reference}</TableCell>
                          <TableCell className="text-white/80">
                            {verse.text.length > 50 ? `${verse.text.substring(0, 50)}...` : verse.text}
                          </TableCell>
                          <TableCell>
                            {verse.active ? (
                              <span className="flex items-center text-green-500">
                                <CheckCircle className="w-4 h-4 mr-1" /> Ativo
                              </span>
                            ) : (
                              <span className="flex items-center text-red-400">
                                <XCircle className="w-4 h-4 mr-1" /> Inativo
                              </span>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleToggleActive(verse)}
                                title={verse.active ? "Desativar" : "Ativar"}
                              >
                                {verse.active ? (
                                  <XCircle className="h-5 w-5 text-red-400" />
                                ) : (
                                  <CheckCircle className="h-5 w-5 text-green-500" />
                                )}
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleEdit(verse)}
                                title="Editar"
                              >
                                <Edit className="h-5 w-5 text-indigo-400" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDelete(verse.id)}
                                title="Excluir"
                              >
                                <Trash2 className="h-5 w-5 text-red-400" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => enterFullscreen(verse)}
                                title="Tela Cheia"
                              >
                                <Maximize2 className="h-5 w-5 text-blue-400" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}