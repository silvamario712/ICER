
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  ArrowLeft, 
  CheckCircle2, 
  XCircle, 
  Timer, 
  Award, 
  ChevronRight,
  RefreshCw,
  AlertCircle,
  Sparkles,
  Trophy
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { QuizQuestion } from "@/api/entities";
import { UserScore } from "@/api/entities";
import { User } from "@/api/entities";

export default function BibleQuiz() {
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [userScore, setUserScore] = useState(null);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30);
  const [timer, setTimer] = useState(null);
  const [leaderboard, setLeaderboard] = useState([]);
  const [quizId, setQuizId] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    async function fetchQuestionsAndUserData() {
      try {
        const sessionId = `quiz_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
        setQuizId(sessionId);
        
        try {
          const user = await User.me();
          setIsAdmin(user.role === 'admin');
        } catch (error) {
          console.log("Usuário não autenticado");
        }
        
        const fetchedQuestions = await QuizQuestion.list();
        let availableQuestions = fetchedQuestions.filter(q => q.active === true);
        
        if (availableQuestions.length === 0) {
          throw new Error("Nenhuma pergunta disponível");
        }
        
        let selectedQuestions = [];
        
        const difficultQuestions = availableQuestions
          .filter(q => q.difficulty === "difícil")
          .sort(() => 0.5 - Math.random());
        selectedQuestions.push(...difficultQuestions.slice(0, 5));
        
        if (selectedQuestions.length < 5) {
          const mediumQuestions = availableQuestions
            .filter(q => q.difficulty === "médio")
            .sort(() => 0.5 - Math.random())
            .slice(0, 5 - selectedQuestions.length);
          selectedQuestions.push(...mediumQuestions);
        }
        
        if (selectedQuestions.length < 5) {
          const easyQuestions = availableQuestions
            .filter(q => q.difficulty === "fácil")
            .sort(() => 0.5 - Math.random())
            .slice(0, 5 - selectedQuestions.length);
          selectedQuestions.push(...easyQuestions);
        }
        
        if (selectedQuestions.length === 0) {
          selectedQuestions = availableQuestions
            .sort(() => 0.5 - Math.random())
            .slice(0, 5);
        }
        
        setQuestions(selectedQuestions);
        
        try {
          const user = await User.me();
          let userScores = await UserScore.filter({ created_by: user.email });
          
          if (!userScores || userScores.length === 0) {
            const newUserScore = await UserScore.create({
              total_score: 0,
              correct_answers: 0,
              wrong_answers: 0,
              questions_answered: 0
            });
            setUserScore(newUserScore);
          } else {
            setUserScore(userScores[0]);
          }
          
          const allUserScores = await UserScore.list('-total_score', 10);
          setLeaderboard(allUserScores);
        } catch (error) {
          console.log("Erro ao carregar pontuações de usuário:", error);
        }
        
      } catch (error) {
        console.error("Erro ao buscar dados do quiz:", error);
        setQuestions([]);
      } finally {
        setLoading(false);
      }
    }
    
    fetchQuestionsAndUserData();
  }, []);

  useEffect(() => {
    if (questions.length > 0 && !isAnswered && !quizCompleted) {
      setTimeLeft(60);
      const countdown = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(countdown);
            handleTimeout();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      
      setTimer(countdown);
      return () => clearInterval(countdown);
    }
  }, [currentQuestionIndex, questions, isAnswered, quizCompleted]);

  const handleTimeout = () => {
    if (!isAnswered) {
      setIsAnswered(true);
      updateUserScore(false);
    }
  };

  const handleOptionSelect = (index) => {
    if (isAnswered) return;
    
    setSelectedOption(index);
    setIsAnswered(true);
    clearInterval(timer);
    
    const question = questions[currentQuestionIndex];
    const isCorrect = index === question.correctOptionIndex;
    
    if (isCorrect) {
      const pointsEarned = 2;
      setScore(prevScore => prevScore + pointsEarned);
    }
    
    updateUserScore(isCorrect);
  };

  const updateUserScore = async (isCorrect) => {
    if (!userScore) return;
    
    try {
      const updatedScore = {
        total_score: userScore.total_score + (isCorrect ? 2 : 0),
        correct_answers: userScore.correct_answers + (isCorrect ? 1 : 0),
        wrong_answers: userScore.wrong_answers + (isCorrect ? 0 : 1),
        questions_answered: userScore.questions_answered + 1,
        last_quiz_date: new Date().toISOString()
      };
      
      const updated = await UserScore.update(userScore.id, updatedScore);
      setUserScore(updated);
      
      const newLeaderboard = await UserScore.list('-total_score', 10);
      setLeaderboard(newLeaderboard);
    } catch (error) {
      console.error("Erro ao atualizar pontuação:", error);
    }
  };

  const goToNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setQuizCompleted(true);
    }
  };

  const restartQuiz = async () => {
    try {
      setLoading(true);
      
      const fetchedQuestions = await QuizQuestion.list();
      let availableQuestions = fetchedQuestions.filter(q => q.active === true);
      
      if (availableQuestions.length === 0) {
        throw new Error("Nenhuma pergunta disponível");
      }
      
      let selectedQuestions = [];
      
      const difficultQuestions = availableQuestions
        .filter(q => q.difficulty === "difícil")
        .sort(() => 0.5 - Math.random());
      selectedQuestions.push(...difficultQuestions.slice(0, 5));
      
      if (selectedQuestions.length < 5) {
        const mediumQuestions = availableQuestions
          .filter(q => q.difficulty === "médio")
          .sort(() => 0.5 - Math.random())
          .slice(0, 5 - selectedQuestions.length);
        selectedQuestions.push(...mediumQuestions);
      }
      
      if (selectedQuestions.length < 5) {
        const easyQuestions = availableQuestions
          .filter(q => q.difficulty === "fácil")
          .sort(() => 0.5 - Math.random())
          .slice(0, 5 - selectedQuestions.length);
        selectedQuestions.push(...easyQuestions);
      }
      
      if (selectedQuestions.length === 0) {
        selectedQuestions = availableQuestions
          .sort(() => 0.5 - Math.random())
          .slice(0, 5);
      }
      
      setQuestions(selectedQuestions);
      setCurrentQuestionIndex(0);
      setSelectedOption(null);
      setIsAnswered(false);
      setScore(0);
      setQuizCompleted(false);
      setTimeLeft(30);
      
    } catch (error) {
      console.error("Erro ao reiniciar quiz:", error);
      setQuestions([]);
    } finally {
      setLoading(false);
    }
  };

  const difficultyColors = {
    'fácil': 'bg-green-600',
    'médio': 'bg-yellow-600',
    'difícil': 'bg-red-600'
  };

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Link to={createPageUrl("Home")}>
          <Button variant="ghost" className="mb-4 text-white/80 hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-2" /> Voltar
          </Button>
        </Link>
        
        {isAdmin && (
          <Link to={createPageUrl("BibleQuizAdmin")}>
            <Button variant="outline" className="mb-4 text-white/80 hover:text-white">
              Administrar Quiz
            </Button>
          </Link>
        )}
      </div>
      
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold text-white">Quiz Bíblico</h1>
        <p className="text-white/60 mt-2">Cada resposta correta vale 2 pontos</p>
      </div>

      {loading ? (
        <Card className="bg-gray-900/90 border border-white/10 shadow-[0_0_30px_rgba(255,255,255,0.05)]">
          <CardContent className="p-10 flex justify-center">
            <div className="h-24 flex items-center justify-center">
              <div className="animate-pulse flex space-x-4">
                <div className="rounded-full bg-white/10 h-12 w-12"></div>
                <div className="flex-1 space-y-4 py-1">
                  <div className="h-4 bg-white/10 rounded w-3/4"></div>
                  <div className="space-y-2">
                    <div className="h-4 bg-white/10 rounded"></div>
                    <div className="h-4 bg-white/10 rounded w-5/6"></div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : quizCompleted ? (
        <Card className="bg-gray-900/90 border border-white/10 shadow-[0_0_30px_rgba(255,255,255,0.05)]">
          <CardHeader className="text-center border-b border-white/10">
            <Trophy className="w-16 h-16 mx-auto text-yellow-500 mb-2" />
            <CardTitle className="text-2xl text-white">Quiz Completo!</CardTitle>
          </CardHeader>
          <CardContent className="pt-6 pb-4 px-6">
            <div className="text-center mb-8">
              <h3 className="text-3xl font-bold text-white mb-1">{score} pontos</h3>
              <p className="text-white/60">
                Você acertou {score / 2} de {questions.length} perguntas
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold text-white mb-3 flex items-center">
                  <Award className="w-5 h-5 mr-2 text-yellow-500" />
                  Sua Pontuação Total
                </h3>
                <div className="bg-gray-800/60 rounded-lg p-4 border border-white/10">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <p className="text-white/60 text-sm">Pontuação</p>
                      <p className="text-xl font-bold text-white">{userScore?.total_score || 0}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-white/60 text-sm">Acertos</p>
                      <p className="text-xl font-bold text-white">{userScore?.correct_answers || 0}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-white/60 text-sm">Perguntas</p>
                      <p className="text-xl font-bold text-white">{userScore?.questions_answered || 0}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-white/60 text-sm">Precisão</p>
                      <p className="text-xl font-bold text-white">
                        {userScore?.questions_answered ? 
                          Math.round((userScore.correct_answers / userScore.questions_answered) * 100) : 0}%
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-white mb-3 flex items-center">
                  <Trophy className="w-5 h-5 mr-2 text-yellow-500" />
                  Ranking
                </h3>
                <div className="bg-gray-800/60 rounded-lg p-4 border border-white/10">
                  <ScrollArea className="h-[180px]">
                    <div className="space-y-2">
                      {leaderboard.map((user, index) => {
                        const isCurrentUser = userScore && user.id === userScore.id;
                        return (
                          <div 
                            key={user.id} 
                            className={`flex items-center justify-between p-2 rounded ${isCurrentUser ? 'bg-white/10' : ''}`}
                          >
                            <div className="flex items-center">
                              <div className={`w-6 h-6 rounded-full flex items-center justify-center mr-2 
                                ${index === 0 ? 'bg-yellow-500' : 
                                  index === 1 ? 'bg-gray-400' : 
                                    index === 2 ? 'bg-amber-700' : 'bg-gray-700'} text-white font-bold text-xs`}>
                                {index + 1}
                              </div>
                              <span className={`${isCurrentUser ? 'text-white font-medium' : 'text-white/70'}`}>
                                {isCurrentUser ? 'Você' : `Usuário ${index + 1}`}
                              </span>
                            </div>
                            <span className="text-white font-semibold">{user.total_score}</span>
                          </div>
                        );
                      })}
                      
                      {leaderboard.length === 0 && (
                        <div className="text-center py-4 text-white/60">
                          Nenhuma pontuação registrada ainda.
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="border-t border-white/10 pt-4 pb-6 px-6 flex justify-center">
            <Button 
              onClick={restartQuiz} 
              className="bg-white/10 hover:bg-white/20 text-white"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Iniciar Novo Quiz
            </Button>
          </CardFooter>
        </Card>
      ) : questions.length > 0 ? (
        <Card className="bg-gray-900/90 border border-white/10 shadow-[0_0_30px_rgba(255,255,255,0.05)]">
          <CardHeader className="border-b border-white/10 pb-4">
            <div className="flex justify-between items-center">
              <div className="flex flex-col">
                <div className="flex items-center">
                  <Badge className={`${difficultyColors[currentQuestion.difficulty] || 'bg-blue-600'} text-white`}>
                    {currentQuestion.difficulty || 'médio'}
                  </Badge>
                  <span className="text-white/60 ml-3 text-sm">
                    Pergunta {currentQuestionIndex + 1} de {questions.length}
                  </span>
                </div>
                <div className="mt-2 w-full">
                  <Progress value={(currentQuestionIndex / questions.length) * 100} className="h-1 bg-gray-800" />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Timer className="w-4 h-4 text-white/60" />
                <span className={`text-sm font-medium ${timeLeft < 10 ? 'text-red-400' : 'text-white/80'}`}>
                  {timeLeft}s
                </span>
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="p-6">
            <div className="space-y-6">
              <h2 className="text-xl font-semibold text-white mb-6">{currentQuestion.question}</h2>
              
              <div className="space-y-3">
                {currentQuestion.options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleOptionSelect(index)}
                    disabled={isAnswered}
                    className={`w-full text-left p-4 rounded-lg border transition-all ${
                      isAnswered
                        ? index === currentQuestion.correctOptionIndex
                          ? 'bg-green-500/20 border-green-500/50 text-white'
                          : index === selectedOption
                          ? 'bg-red-500/20 border-red-500/50 text-white'
                          : 'bg-gray-800/40 border-white/5 text-white/60'
                        : selectedOption === index
                        ? 'bg-white/10 border-white/20 text-white'
                        : 'bg-gray-800/40 border-white/5 text-white/80 hover:bg-white/5 hover:border-white/10'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>{option}</span>
                      {isAnswered && index === currentQuestion.correctOptionIndex && (
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                      )}
                      {isAnswered && index === selectedOption && index !== currentQuestion.correctOptionIndex && (
                        <XCircle className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </CardContent>
          
          {isAnswered && (
            <CardFooter className="border-t border-white/10 p-4">
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center">
                  {selectedOption === currentQuestion.correctOptionIndex ? (
                    <div className="flex items-center text-green-500">
                      <Sparkles className="w-5 h-5 mr-2" />
                      <span>Correto! +2 pontos</span>
                    </div>
                  ) : (
                    <div className="flex items-center text-red-400">
                      <AlertCircle className="w-5 h-5 mr-2" />
                      <span>Incorreto</span>
                    </div>
                  )}
                </div>
                <Button onClick={goToNextQuestion} className="bg-white/10 hover:bg-white/20 text-white">
                  {currentQuestionIndex < questions.length - 1 ? (
                    <>
                      Próxima Pergunta
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </>
                  ) : (
                    <>
                      Finalizar Quiz
                      <Trophy className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>
              </div>
            </CardFooter>
          )}
        </Card>
      ) : (
        <Card className="bg-gray-900/90 border border-white/10">
          <CardContent className="p-6 text-center">
            <p className="text-white/60">Nenhuma pergunta disponível no momento.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
