

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { User } from "@/api/entities";
import { 
  Menu,
  X,
  MapPin,
  Instagram,
  Youtube,
  Facebook
} from "lucide-react";

export default function Layout({ children, user }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [ministryDropdown, setMinistryDropdown] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <div className="flex flex-col min-h-screen bg-gray-950">
      <header className={`sticky top-0 z-50 transition-all duration-300 ${scrolled ? 'bg-gray-900/95 shadow-[0_0_15px_rgba(255,255,255,0.1)]' : 'bg-gray-900/80 backdrop-blur-sm'} py-4`}>
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center">
            <Link to={createPageUrl("Home")} className="flex items-center gap-4">
              <div className="relative w-20 h-20 rounded-full overflow-hidden border-2 border-white/20 flex items-center justify-center bg-gray-900 shadow-[0_0_20px_rgba(255,255,255,0.1)]">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/163421_logoicer.png" 
                  alt="ICER Logo" 
                  className="w-16 h-16 object-contain"
                />
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-bold text-white">ICER AMOR SINCERO POR JESUS</span>
                <span className="text-lg font-semibold text-white/80">LUGAR DE GENTE FELIZ</span>
              </div>
            </Link>

            <div className="hidden md:flex items-center gap-8">
              <Link to={createPageUrl("Events")} className="text-white/80 hover:text-white transition-colors">
                Eventos
              </Link>
              {user?.role === 'admin' && (
                <Link to={createPageUrl("BibleQuizAdmin")} className="text-white/80 hover:text-white transition-colors">
                  ICER Colaboração
                </Link>
              )}
              {user ? (
                <div className="flex items-center gap-2">
                  <span className="text-white/60">{user.full_name}</span>
                  <Button 
                    variant="ghost" 
                    className="text-white/80 hover:text-white"
                    onClick={() => User.logout()}
                  >
                    Sair
                  </Button>
                </div>
              ) : (
                <Button 
                  variant="ghost" 
                  className="text-white/80 hover:text-white"
                  onClick={() => User.login()}
                >
                  Entrar
                </Button>
              )}
            </div>

            <div className="md:hidden">
              <button 
                onClick={() => setMenuOpen(!menuOpen)}
                className="p-2 text-white hover:text-gray-300"
              >
                {menuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {menuOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-gray-900">
          <div className="p-4 flex justify-between items-center border-b">
            <div className="flex items-center gap-2">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/163421_logoicer.png" 
                alt="ICER Logo" 
                className="w-10 h-10"
              />
              <div className="font-bold text-white">ICER AMOR SINCERO POR JESUS <span className="text-sm font-normal">LUGAR DE GENTE FELIZ</span></div>
            </div>
            <button onClick={() => setMenuOpen(false)}>
              <X size={24} className="text-white" />
            </button>
          </div>

          <nav className="p-4">
            <ul className="space-y-4">
              <li>
                <Link 
                  to={createPageUrl("Events")}
                  className="block px-4 py-2 text-white/70 hover:bg-white/10 hover:text-white rounded-md transition-colors"
                  onClick={() => setMenuOpen(false)}
                >
                  Eventos
                </Link>
              </li>
              {user?.role === 'admin' && (
                <li>
                  <Link 
                    to={createPageUrl("BibleQuizAdmin")}
                    className="block px-4 py-2 text-white/70 hover:bg-white/10 hover:text-white rounded-md transition-colors"
                    onClick={() => setMenuOpen(false)}
                  >
                    ICER Colaboração
                  </Link>
                </li>
              )}
              <li>
                {user ? (
                  <div className="px-4 py-2 flex justify-between items-center">
                    <span className="text-white/60">{user.full_name}</span>
                    <Button 
                      variant="ghost" 
                      className="text-white/80 hover:text-white"
                      onClick={() => {
                        User.logout();
                        setMenuOpen(false);
                      }}
                    >
                      Sair
                    </Button>
                  </div>
                ) : (
                  <Button 
                    variant="ghost" 
                    className="w-full text-white/80 hover:text-white"
                    onClick={() => {
                      User.login();
                      setMenuOpen(false);
                    }}
                  >
                    Entrar
                  </Button>
                )}
              </li>
            </ul>
          </nav>
        </div>
      )}

      <main className="flex-1">
        {children}
      </main>

      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div>
              <div className="flex items-center gap-4 mb-6">
                <div className="bg-gray-800 p-2 rounded-lg border border-white/10">
                  <img
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/163421_logoicer.png"
                    alt="ICER Logo"
                    className="w-14 h-14 object-contain"
                  />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">ICER AMOR SINCERO POR JESUS</h2>
                  <p className="text-sm text-white/60">LUGAR DE GENTE FELIZ</p>
                </div>
              </div>
              <p className="text-white/60 mb-4">Amor Sincero por Jesus</p>
              <div className="flex gap-4">
                <a href="https://www.instagram.com/igrejaicer" target="_blank" rel="noopener noreferrer" className="text-white/60 hover:text-white transition-colors">
                  <Instagram />
                </a>
                <a href="https://www.youtube.com/@iceramorsinceroporjesus?si=4LxFYRNJnd3fjhO0" target="_blank" rel="noopener noreferrer" className="text-white/60 hover:text-white transition-colors">
                  <Youtube />
                </a>
                <a href="https://www.facebook.com/igrejaicer" target="_blank" rel="noopener noreferrer" className="text-white/60 hover:text-white transition-colors">
                  <Facebook />
                </a>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Contato</h3>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-white/60 mt-1" />
                  <p className="text-white/60">Av Bela Vista 293 Jd. Bonifacio, São João de Meriti CEP 25575400</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Horários</h3>
              <div className="space-y-2">
                <div className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-blue-400 mr-2"></div>
                  <p className="text-white/60">Quartas às 19:30h - Culto de Adoração</p>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-blue-400 mr-2"></div>
                  <p className="text-white/60">Domingos às 09h - EBD Escola Bíblica Dominical</p>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-blue-400 mr-2"></div>
                  <p className="text-white/60">Domingos às 18:30h - Culto de Adoração</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12 pt-6 border-t border-white/10 text-center text-white/40 text-sm">
            <p>&copy; {new Date().getFullYear()} Igreja Cristã Evangélica Renovada ICER AMOR SINCERO POR JESUS. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

