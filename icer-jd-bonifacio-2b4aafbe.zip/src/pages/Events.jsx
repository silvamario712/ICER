
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Upload, 
  Calendar as CalendarIcon, 
  Play, 
  Plus, 
  Trash2, 
  Video, 
  ArrowLeft,
  Link as LinkIcon,
  Clock,
  CalendarDays,
  AlertCircle,
  RefreshCw
} from "lucide-react";
import { User } from "@/api/entities";
import { Event } from "@/api/entities";
import { UploadFile } from "@/api/integrations";
import EventCard from "../components/EventCard";
import EventCalendar from "../components/EventCalendar";

export default function Events() {
  const [events, setEvents] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [activeTab, setActiveTab] = useState("próximos");

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    date: "",
    time: "",
    registration_link: "",
    video_url: "",
    type: "mp4",
    status: "próximo",
    active: true
  });

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        setError(null);
        
        try {
          const user = await User.me();
          setIsAdmin(user.role === 'admin');
        } catch (error) {
          setIsAdmin(false);
          console.log("Usuário não autenticado ou não é admin");
        }
        
        try {
          const fetchedEvents = await Event.list('-date');
          setEvents(fetchedEvents);
        } catch (err) {
          console.error("Erro ao carregar eventos:", err);
          setError("Não foi possível carregar os eventos. Tente novamente mais tarde.");
        }
      } catch (error) {
        console.error("Erro ao carregar dados:", error);
        setError("Ocorreu um erro ao carregar dados. Verifique sua conexão.");
      } finally {
        setLoading(false);
      }
    }
    
    loadData();
  }, []);

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const fileType = file.name.split('.').pop().toLowerCase();
      if (!['mp4', 'mpeg', 'avi', 'divx'].includes(fileType)) {
        alert('Formato de arquivo não suportado. Use mp4, mpeg, avi ou divx.');
        return;
      }
      setSelectedFile(file);
      setFormData({ ...formData, type: fileType });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      let videoUrl = formData.video_url;

      if (selectedFile) {
        const uploadResult = await UploadFile({ file: selectedFile });
        videoUrl = uploadResult.file_url;
      }

      await Event.create({
        ...formData,
        video_url: videoUrl
      });

      setFormData({
        title: "",
        description: "",
        date: "",
        time: "",
        registration_link: "",
        video_url: "",
        type: "mp4",
        status: "próximo",
        active: true
      });
      setSelectedFile(null);
      setShowForm(false);
      
      const updatedEvents = await Event.list('-date');
      setEvents(updatedEvents);
    } catch (error) {
      console.error("Erro ao salvar evento:", error);
      alert("Erro ao salvar evento. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (eventId) => {
    if (window.confirm("Tem certeza que deseja excluir este evento?")) {
      try {
        setLoading(true);
        await Event.delete(eventId);
        const updatedEvents = await Event.list('-date');
        setEvents(updatedEvents);
      } catch (error) {
        console.error("Erro ao excluir evento:", error);
      } finally {
        setLoading(false);
      }
    }
  };

  const filteredEvents = events.filter(event => {
    if (activeTab === "próximos") return event.status === "próximo";
    if (activeTab === "em_andamento") return event.status === "em_andamento";
    if (activeTab === "finalizados") return event.status === "finalizado";
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <Link to={createPageUrl("Home")}>
          <Button variant="ghost" className="mb-4 text-white/80 hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-2" /> Voltar
          </Button>
        </Link>
        <h1 className="text-3xl font-bold text-white">Agenda de Eventos</h1>
        {isAdmin && (
          <Button 
            onClick={() => setShowForm(!showForm)}
            className="bg-indigo-600 hover:bg-indigo-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Novo Evento
          </Button>
        )}
      </div>

      {showForm && isAdmin && (
        <Card className="bg-gray-900/90 border border-white/10">
          <CardHeader>
            <CardTitle className="text-white">Adicionar Novo Evento</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title" className="text-white">Título</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  className="bg-gray-800 border-white/10 text-white"
                  required
                />
              </div>

              <div>
                <Label htmlFor="description" className="text-white">Descrição</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  className="bg-gray-800 border-white/10 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-white">Data</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full bg-gray-800 border-white/10 text-white"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.date ? format(new Date(formData.date), 'PPP') : 'Selecione a data'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.date ? new Date(formData.date) : undefined}
                        onSelect={(date) => setFormData({...formData, date: date})}
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div>
                  <Label htmlFor="time" className="text-white">Horário</Label>
                  <Input
                    id="time"
                    type="time"
                    value={formData.time}
                    onChange={(e) => setFormData({...formData, time: e.target.value})}
                    className="bg-gray-800 border-white/10 text-white"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="registration_link" className="text-white">Link de Inscrição</Label>
                <Input
                  id="registration_link"
                  value={formData.registration_link}
                  onChange={(e) => setFormData({...formData, registration_link: e.target.value})}
                  placeholder="https://"
                  className="bg-gray-800 border-white/10 text-white"
                />
              </div>

              <div>
                <Label className="text-white">Status do Evento</Label>
                <Select 
                  value={formData.status}
                  onValueChange={(value) => setFormData({...formData, status: value})}
                >
                  <SelectTrigger className="bg-gray-800 border-white/10 text-white">
                    <SelectValue placeholder="Selecione o status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="próximo">Próximo</SelectItem>
                    <SelectItem value="em_andamento">Em Andamento</SelectItem>
                    <SelectItem value="finalizado">Finalizado</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-white">Vídeo</Label>
                <div className="flex gap-4">
                  <Input
                    type="file"
                    accept=".mp4,.mpeg,.avi,.divx"
                    onChange={handleFileChange}
                    className="bg-gray-800 border-white/10 text-white"
                  />
                  <Button 
                    type="submit"
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Salvar
                  </Button>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <EventCalendar />

      {error ? (
        <Card className="bg-gray-900/90 border border-red-500/30">
          <CardContent className="p-6 text-center">
            <div className="text-red-400 mb-2">
              <AlertCircle className="w-10 h-10 mx-auto mb-2" />
              <p className="text-lg font-semibold">Oops! Algo deu errado</p>
            </div>
            <p className="text-white/70">{error}</p>
            <Button 
              onClick={() => window.location.reload()} 
              className="mt-4 bg-red-600 hover:bg-red-700"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Tentar novamente
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Tabs defaultValue="próximos" className="w-full" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-6">
            <TabsTrigger value="próximos">Próximos</TabsTrigger>
            <TabsTrigger value="em_andamento">Em Andamento</TabsTrigger>
            <TabsTrigger value="finalizados">Finalizados</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab}>
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3].map(item => (
                  <Card key={item} className="bg-gray-900/90 border border-white/10 h-64 animate-pulse">
                    <CardHeader className="border-b border-white/10">
                      <div className="h-6 bg-white/10 rounded w-3/4"></div>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="space-y-2">
                        <div className="h-4 bg-white/10 rounded"></div>
                        <div className="h-4 bg-white/10 rounded w-5/6"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredEvents.map((event) => (
                  <EventCard 
                    key={event.id} 
                    event={event} 
                    isAdmin={isAdmin}
                    onEdit={(event) => {
                      setFormData({
                        ...event,
                        date: new Date(event.date)
                      });
                      setShowForm(true);
                    }}
                    onDelete={handleDelete}
                  />
                ))}

                {filteredEvents.length === 0 && !loading && (
                  <div className="col-span-full text-center py-12 text-white/60">
                    Nenhum evento {activeTab === "próximos" ? "próximo" : 
                                  activeTab === "em_andamento" ? "em andamento" : 
                                  "finalizado"}.
                  </div>
                )}
              </div>
            )}
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
