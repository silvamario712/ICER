import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Lightbulb, Share2, Calendar, Edit } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { BibleVerse } from "@/api/entities";
import { User } from "@/api/entities";
import { format } from "date-fns";

export default function DailyWord() {
  const [verse, setVerse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [recentVerses, setRecentVerses] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    async function fetchVerses() {
      try {
        // Verificar se é admin
        try {
          const user = await User.me();
          setIsAdmin(user.role === 'admin');
        } catch (error) {
          console.log("Usuário não autenticado");
        }
        
        // Fetch today's verse
        const today = new Date().toISOString().split('T')[0];
        const todayVerses = await BibleVerse.filter({ date: today, active: true });
        
        if (todayVerses && todayVerses.length > 0) {
          setVerse(todayVerses[0]);
        } else {
          // Fallback to most recent verse
          const allVerses = await BibleVerse.list('-date', 1);
          if (allVerses && allVerses.length > 0) {
            setVerse(allVerses[0]);
          }
        }

        // Fetch recent verses (excluding today)
        const recent = await BibleVerse.list('-date', 7);
        setRecentVerses(recent.filter(v => v.date !== today).slice(0, 5));
      } catch (error) {
        console.error("Erro ao buscar versículos:", error);
      } finally {
        setLoading(false);
      }
    }

    fetchVerses();
  }, []);

  const handleShare = () => {
    if (verse) {
      if (navigator.share) {
        navigator.share({
          title: 'Palavra do Dia - ICER AMOR SINCERO POR JESUS',
          text: `"${verse.text}" — ${verse.reference}`,
          url: window.location.href,
        });
      } else {
        // Fallback for browsers that don't support Web Share API
        navigator.clipboard.writeText(`"${verse.text}" — ${verse.reference}`);
        alert('Versículo copiado para a área de transferência!');
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <Link to={createPageUrl("Home")}>
          <Button variant="ghost" className="mb-4 text-white/80 hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-2" /> Voltar
          </Button>
        </Link>
        
        {isAdmin && (
          <Link to={createPageUrl("DailyWordAdmin")}>
            <Button variant="outline" className="mb-4 text-white/80 hover:text-white">
              <Edit className="w-4 h-4 mr-2" />
              Administrar Palavra do Dia
            </Button>
          </Link>
        )}
      </div>
      
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold text-white">Palavra do Dia</h1>
        <p className="text-white/60 mt-2">Versículos para edificação espiritual</p>
      </div>
      
      {loading ? (
        <Card className="bg-gray-900/90 border border-white/10 shadow-[0_0_30px_rgba(255,255,255,0.05)]">
          <CardContent className="p-10 flex justify-center">
            <div className="h-24 flex items-center justify-center">
              <div className="animate-pulse flex space-x-4">
                <div className="rounded-full bg-white/10 h-12 w-12"></div>
                <div className="flex-1 space-y-4 py-1">
                  <div className="h-4 bg-white/10 rounded w-3/4"></div>
                  <div className="space-y-2">
                    <div className="h-4 bg-white/10 rounded"></div>
                    <div className="h-4 bg-white/10 rounded w-5/6"></div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : verse ? (
        <Card className="bg-gray-900/90 border border-white/10 shadow-[0_0_30px_rgba(255,255,255,0.05)]">
          <CardHeader className="border-b border-white/10 pb-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <Lightbulb className="h-5 w-5 text-white" />
                <CardTitle className="text-white">Palavra de Hoje</CardTitle>
              </div>
              <div className="text-white/60 text-sm flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                {format(new Date(verse.date), 'dd/MM/yyyy')}
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6 md:p-10 text-center">
            <blockquote className="text-xl md:text-2xl text-white italic mb-6 leading-relaxed">
              "{verse.text}"
            </blockquote>
            <cite className="text-white/80 font-semibold text-lg block mb-6">
              — {verse.reference}
            </cite>
            <div className="flex justify-center gap-4">
              <Button 
                onClick={handleShare} 
                className="bg-white/10 hover:bg-white/20 text-white"
              >
                <Share2 className="h-4 w-4 mr-2" />
                Compartilhar
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="bg-gray-900/90 border border-white/10">
          <CardContent className="p-6 text-center">
            <p className="text-white/60">Nenhum versículo disponível para hoje.</p>
          </CardContent>
        </Card>
      )}

      {recentVerses.length > 0 && (
        <div className="mt-10">
          <h2 className="text-xl font-semibold text-white mb-4">Versículos Recentes</h2>
          <div className="space-y-4">
            {recentVerses.map((v) => (
              <Card key={v.id} className="bg-gray-900/60 border border-white/5 hover:border-white/20 transition-all">
                <CardContent className="p-4">
                  <div className="flex flex-col">
                    <div className="flex justify-between items-start mb-2">
                      <p className="text-white/80 font-medium">{v.reference}</p>
                      <span className="text-white/40 text-xs">{format(new Date(v.date), 'dd/MM')}</span>
                    </div>
                    <p className="text-white/70 text-sm italic">"{v.text.length > 100 ? v.text.substring(0, 100) + '...' : v.text}"</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}