
import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Users, Music, Book, Heart, UserPlus, Gift, BadgeHelp, 
  UserCheck, Baby, School, Droplets, Instagram, MapPin,
  Clock, User, FastForward, Smile, Lightbulb, BrainCircuit, Video,
  Calendar, ArrowRight, Youtube, Edit, Play
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import MinistryCard from '../components/MinistryCard';
import { BibleVerse } from "@/api/entities";
import { User as UserEntity } from "@/api/entities";

export default function Home() {
  const [verse, setVerse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [editMode, setEditMode] = useState(false);

  // Mídias editáveis
  const [mediaInfo, setMediaInfo] = useState({
    youtubePlaylistId: "PLxxxxxxxxxxxxxxx", // Atualizar com o ID correto da playlist
    youtubeChannelUrl: "https://www.youtube.com/@iceramorsinceroporjesus",
    customVideoUrl: null, // Novo campo para vídeo personalizado
    pastorPhoto: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/pastor_thiago.jpg",
    pastorInstagramUrl: "https://www.instagram.com/thiagodiasth/",
    pastorName: "Pastor Thiago Dias",
    pastorTitle: "Pastor Presidente da ICER",
    imageScale: 1,
    imagePosition: 'center'
  });

  useEffect(() => {
    async function fetchTodaysVerse() {
      try {
        const today = new Date().toISOString().split('T')[0];
        const verses = await BibleVerse.filter({ date: today, active: true });
        
        if (verses && verses.length > 0) {
          setVerse(verses[0]);
        } else {
          const allVerses = await BibleVerse.list('-date', 1);
          if (allVerses && allVerses.length > 0) {
            setVerse(allVerses[0]);
          }
        }

        try {
          const user = await UserEntity.me();
          setIsAdmin(user.role === 'admin');
          
          // Carregar configurações salvas (se existirem)
          try {
            if (user.mediaSettings) {
              setMediaInfo({...mediaInfo, ...user.mediaSettings});
            }
          } catch (error) {
            console.log("Nenhuma configuração de mídia encontrada");
          }
          
        } catch (error) {
          console.log("Usuário não autenticado ou não é admin");
          setIsAdmin(false);
        }
      } catch (error) {
        console.error("Erro ao buscar versículo:", error);
      } finally {
        setLoading(false);
      }
    }

    fetchTodaysVerse();
  }, []);

  const handleMediaChange = (field, value) => {
    setMediaInfo({...mediaInfo, [field]: value});
  };

  const saveMediaSettings = async () => {
    try {
      await UserEntity.updateMyUserData({
        mediaSettings: mediaInfo
      });
      alert("Configurações de mídia salvas com sucesso!");
      setEditMode(false);
    } catch (error) {
      console.error("Erro ao salvar configurações:", error);
      alert("Erro ao salvar configurações. Tente novamente.");
    }
  };

  const ministries = [
    { 
      name: "Casais", 
      icon: Users, 
      color: "bg-gray-900/80 text-white hover:bg-gray-800/80 border border-white/10 hover:border-white/20",
      link: "https://www.instagram.com/stories/highlights/17919829745899352/"
    },
    { 
      name: "Adoração", 
      icon: Music, 
      color: "bg-gray-900/80 text-white hover:bg-gray-800/80 border border-white/10 hover:border-white/20",
      link: "https://www.instagram.com/stories/highlights/17985930437788000/"
    },
    { 
      name: "EBD", 
      icon: Book, 
      color: "bg-gray-900/80 text-white hover:bg-gray-800/80 border border-white/10 hover:border-white/20",
      link: "https://www.instagram.com/stories/highlights/17986132970268133/"
    },
    { 
      name: "Jovens", 
      icon: Heart, 
      color: "bg-gray-900/80 text-white hover:bg-gray-800/80 border border-white/10 hover:border-white/20",
      link: "https://www.instagram.com/stories/highlights/17975594951665234/"
    },
    { 
      name: "Contribuição", 
      icon: Gift, 
      color: "bg-gray-900/80 text-white hover:bg-gray-800/80 border border-white/10 hover:border-white/20",
      link: "https://www.instagram.com/stories/highlights/17891139795150037/"
    },
    { 
      name: "Mulheres", 
      icon: UserCheck, 
      color: "bg-gray-900/80 text-white hover:bg-gray-800/80 border border-white/10 hover:border-white/20",
      link: "https://www.instagram.com/stories/highlights/18065445274831849/"
    },
    { 
      name: "Homens", 
      icon: UserPlus, 
      color: "bg-gray-900/80 text-white hover:bg-gray-800/80 border border-white/10 hover:border-white/20",
      link: "https://www.instagram.com/stories/highlights/18086612689385579/"
    },
    { 
      name: "Adolescentes", 
      icon: School, 
      color: "bg-gray-900/80 text-white hover:bg-gray-800/80 border border-white/10 hover:border-white/20",
      link: "https://www.instagram.com/stories/highlights/18016697909310455/"
    },
    { 
      name: "Kids", 
      icon: Baby, 
      color: "bg-gray-900/80 text-white hover:bg-gray-800/80 border border-white/10 hover:border-white/20",
      link: "https://www.instagram.com/stories/highlights/17974766822386390/"
    },
    { 
      name: "Batismos", 
      icon: Droplets, 
      color: "bg-gray-900/80 text-white hover:bg-gray-800/80 border border-white/10 hover:border-white/20",
      link: "https://www.instagram.com/stories/highlights/18233467231213556/"
    },
    { 
      name: "Cultos", 
      icon: Clock, 
      color: "bg-gray-900/80 text-white hover:bg-gray-800/80 border border-white/10 hover:border-white/20",
      link: "https://www.instagram.com/stories/highlights/18034759400162054/"
    },
    { 
      name: "Palavra do Dia", 
      icon: Lightbulb, 
      color: "bg-gray-900/80 text-white hover:bg-gray-800/80 border border-white/10 hover:border-white/20",
      link: createPageUrl("DailyWord")
    },
    { 
      name: "Quiz Bíblico", 
      icon: BrainCircuit, 
      color: "bg-gray-900/80 text-white hover:bg-gray-800/80 border border-white/10 hover:border-white/20",
      link: createPageUrl("BibleQuiz")
    }
  ];

  return (
    <div className="space-y-8">
      {isAdmin && (
        <div className="flex justify-end mb-4">
          <Button
            onClick={() => setEditMode(!editMode)}
            className={`${editMode ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'}`}
          >
            {editMode ? 'Concluir Edição' : 'Editar Mídias'}
            <Edit className="w-4 h-4 ml-2" />
          </Button>
          
          {editMode && (
            <div className="flex gap-2">
              <Button
                onClick={() => {
                  if (window.confirm("Descartar todas as alterações feitas?")) {
                    // Recarregar a página para descartar alterações
                    window.location.reload();
                  }
                }}
                className="bg-red-600 hover:bg-red-700"
              >
                Cancelar
              </Button>
              <Button
                onClick={saveMediaSettings}
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                Salvar Alterações
              </Button>
            </div>
          )}
        </div>
      )}

      {/* Hero Section - Estilo Iraja */}
      <div className="relative h-[70vh] rounded-2xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/80"></div>
        <img 
          src="https://images.unsplash.com/photo-1438232992991-995b7058bbb3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80"
          alt="ICER Background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
            ICER AMOR SINCERO<br/>POR JESUS
          </h1>
          <p className="text-xl md:text-2xl text-white/90 mb-8">LUGAR DE GENTE FELIZ</p>
          <div className="flex gap-4">
            <Button 
              className="bg-blue-600 hover:bg-blue-700 text-white py-6 px-8 text-lg"
              onClick={() => window.open(mediaInfo.youtubeChannelUrl, "_blank")}
            >
              <Youtube className="w-6 h-6 mr-2" />
              Assista Ao Vivo
            </Button>
            <Button 
              className="bg-white/20 backdrop-blur-sm hover:bg-white/30 text-white py-6 px-8 text-lg"
              onClick={() => window.open("https://www.instagram.com/icerjdbonifacio/", "_blank")}
            >
              <Instagram className="w-6 h-6 mr-2" />
              Siga-nos
            </Button>
          </div>
        </div>
      </div>

      {/* Seção de Cards Principais */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
        {/* Card de Louvor e Adoração */}
        <Card className="bg-gradient-to-br from-red-600 to-red-800 text-white overflow-hidden hover:scale-105 transition-transform duration-300">
          {editMode ? (
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-4">Configurar Vídeo</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium block mb-2">ID da Playlist do YouTube</label>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      value={mediaInfo.youtubePlaylistId}
                      onChange={(e) => handleMediaChange('youtubePlaylistId', e.target.value)}
                      className="flex-1 bg-white/10 border border-white/20 rounded px-3 py-2"
                      placeholder="ID da playlist"
                    />
                    <Button 
                      variant="secondary"
                      onClick={() => {
                        if (mediaInfo.youtubePlaylistId) {
                          alert("ID da Playlist confirmado!");
                        } else {
                          alert("Por favor, insira um ID válido.");
                        }
                      }}
                    >
                      Confirmar
                    </Button>
                  </div>
                  <p className="text-xs text-white/60 mt-1">Ex: PLxxxxxxxxxxxxxxx</p>
                </div>

                <div>
                  <label className="text-sm font-medium block mb-2">Ou Faça Upload de Vídeo</label>
                  <div className="flex gap-2">
                    <input 
                      type="file" 
                      accept="video/*"
                      className="hidden"
                      id="worshipVideoInput"
                      onChange={async (e) => {
                        const file = e.target.files[0];
                        if (!file) return;
                        
                        try {
                          alert("Iniciando upload do vídeo...");
                          const { UploadFile } = await import('@/api/integrations');
                          const result = await UploadFile({ file });
                          
                          if (result && result.file_url) {
                            handleMediaChange('customVideoUrl', result.file_url);
                            alert('Vídeo enviado com sucesso!');
                          }
                        } catch (error) {
                          console.error("Erro no upload:", error);
                          alert("Erro ao enviar vídeo. Tente novamente.");
                        }
                      }}
                    />
                    <label 
                      htmlFor="worshipVideoInput"
                      className="flex-1 cursor-pointer bg-white/10 hover:bg-white/20 rounded px-4 py-2 text-center"
                    >
                      Escolher Vídeo
                    </label>
                  </div>
                  {mediaInfo.customVideoUrl && (
                    <p className="text-xs text-green-400 mt-1">✓ Vídeo atual: {mediaInfo.customVideoUrl.split('/').pop()}</p>
                  )}
                </div>
              </div>
            </CardContent>
          ) : (
            <div className="h-full">
              <div className="aspect-[16/9] relative">
                {mediaInfo.customVideoUrl ? (
                  <video 
                    src={mediaInfo.customVideoUrl}
                    controls
                    autoPlay
                    muted
                    loop
                    className="w-full h-full object-cover"
                  >
                    Seu navegador não suporta o elemento de vídeo.
                  </video>
                ) : (
                  <iframe 
                    width="100%" 
                    height="100%" 
                    src={`https://www.youtube.com/embed/videoseries?list=${mediaInfo.youtubePlaylistId}&autoplay=1&mute=1`}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="absolute inset-0"
                  ></iframe>
                )}
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-bold mb-2">Louvor e Adoração ao Vivo</h3>
                    <p className="text-white/80">Assista nossos momentos de adoração</p>
                  </div>
                  <Play className="w-8 h-8" />
                </div>
              </div>
            </div>
          )}
        </Card>

        {/* Card do Pastor */}
        <Card className="bg-gradient-to-br from-blue-600 to-blue-800 text-white overflow-hidden hover:scale-105 transition-transform duration-300">
          {editMode ? (
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-4">Configurar Foto do Pastor</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium block mb-2">Foto do Pastor</label>
                  <div className="flex gap-2">
                    <input 
                      type="file" 
                      accept="image/*"
                      className="hidden"
                      id="pastorPhotoInput"
                      onChange={async (e) => {
                        const file = e.target.files[0];
                        if (!file) return;
                        
                        try {
                          const { UploadFile } = await import('@/api/integrations');
                          const result = await UploadFile({ file });
                          
                          if (result && result.file_url) {
                            handleMediaChange('pastorPhoto', result.file_url);
                            // Definir valores padrão para o zoom e posição
                            handleMediaChange('imageScale', 1);
                            handleMediaChange('imagePosition', 'center');
                            alert('Foto atualizada com sucesso!');
                          }
                        } catch (error) {
                          console.error("Erro no upload:", error);
                          alert("Erro ao atualizar foto. Tente novamente.");
                        }
                      }}
                    />
                    <label 
                      htmlFor="pastorPhotoInput"
                      className="flex-1 cursor-pointer bg-white/10 hover:bg-white/20 rounded px-4 py-2 text-center"
                    >
                      Escolher Nova Foto
                    </label>
                  </div>
                </div>

                {/* Controles de Imagem */}
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium block mb-2">Zoom da Imagem</label>
                    <div className="flex items-center gap-3">
                      <input 
                        type="range" 
                        min="0.5" 
                        max="2" 
                        step="0.1"
                        value={mediaInfo.imageScale || 1}
                        onChange={(e) => handleMediaChange('imageScale', parseFloat(e.target.value))}
                        className="flex-1"
                      />
                      <span className="text-sm">
                        {((mediaInfo.imageScale || 1) * 100).toFixed(0)}%
                      </span>
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium block mb-2">Posição da Imagem</label>
                    <div className="grid grid-cols-3 gap-2">
                      {['top', 'center', 'bottom'].map(position => (
                        <Button
                          key={position}
                          variant={mediaInfo.imagePosition === position ? "default" : "outline"}
                          className={`${mediaInfo.imagePosition === position ? 'bg-blue-500' : 'bg-white/10'} text-white`}
                          onClick={() => handleMediaChange('imagePosition', position)}
                        >
                          {position.charAt(0).toUpperCase() + position.slice(1)}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Preview */}
                <div>
                  <label className="text-sm font-medium block mb-2">Preview</label>
                  <div 
                    className="relative h-48 overflow-hidden rounded border border-white/20"
                    style={{
                      background: `url(${mediaInfo.pastorPhoto}) no-repeat`,
                      backgroundSize: `${(mediaInfo.imageScale || 1) * 100}%`,
                      backgroundPosition: mediaInfo.imagePosition || 'center'
                    }}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium block mb-2">Instagram</label>
                  <input 
                    type="text" 
                    value={mediaInfo.pastorInstagramUrl}
                    onChange={(e) => handleMediaChange('pastorInstagramUrl', e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded px-3 py-2"
                  />
                </div>
              </div>
            </CardContent>
          ) : (
            <div className="relative h-full">
              <div 
                className="h-48 overflow-hidden"
                style={{
                  background: `url(${mediaInfo.pastorPhoto}) no-repeat`,
                  backgroundSize: `${(mediaInfo.imageScale || 1) * 100}%`,
                  backgroundPosition: mediaInfo.imagePosition || 'center'
                }}
              />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{mediaInfo.pastorName}</h3>
                <p className="text-white/80 mb-4">{mediaInfo.pastorTitle}</p>
                <a 
                  href={mediaInfo.pastorInstagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-white hover:text-white/80"
                >
                  <Instagram className="w-5 h-5 mr-2" />
                  Siga no Instagram
                </a>
              </div>
            </div>
          )}
        </Card>

        {/* Card dos Horários */}
        <Card className="bg-gradient-to-br from-green-600 to-green-800 text-white overflow-hidden hover:scale-105 transition-transform duration-300">
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold">Horários dos Cultos</h3>
              <Calendar className="w-8 h-8" />
            </div>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-white/80" />
                <div>
                  <p className="font-semibold">Quartas-feiras</p>
                  <p className="text-white/80">19:30h - Culto de Adoração</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-white/80" />
                <div>
                  <p className="font-semibold">Domingos</p>
                  <p className="text-white/80">09:00h - EBD</p>
                  <p className="text-white/80">18:30h - Culto de Adoração</p>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Seção da Palavra do Dia - Estilo Iraja */}
      {verse && (
        <div className="mt-12 bg-gradient-to-r from-gray-900 to-black rounded-2xl p-8 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <Book className="w-full h-full" />
          </div>
          <div className="relative z-10 text-center max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold text-white mb-6">Palavra do Dia</h2>
            <p className="text-xl text-white/90 italic mb-4">"{verse.text}"</p>
            <p className="text-lg text-white/70">{verse.reference}</p>
            <Link 
              to={createPageUrl("DailyWord")} 
              className="inline-block mt-6 text-blue-400 hover:text-blue-300"
            >
              Ver mais versículos →
            </Link>
          </div>
        </div>
      )}

      {/* Seção de Ministérios - Estilo Iraja */}
      <div className="mt-12">
        <h2 className="text-2xl font-bold text-white mb-8">Nossos Ministérios</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {ministries.map((ministry, index) => (
            <MinistryCard 
              key={index}
              name={ministry.name}
              icon={ministry.icon}
              color={ministry.color}
              link={ministry.link}
            />
          ))}
        </div>
      </div>

      {/* Seção de Eventos - Estilo Iraja */}
      <div className="mt-12">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-bold text-white">Próximos Eventos</h2>
          <Link 
            to={createPageUrl("Events")} 
            className="text-blue-400 hover:text-blue-300"
          >
            Ver todos →
          </Link>
        </div>
        <Card className="bg-gradient-to-r from-gray-900 to-black border border-white/10">
          <CardContent className="p-8">
            <div className="flex items-center justify-center h-32">
              <p className="text-white/60">Em breve novos eventos!</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
