import React from 'react';

export default function MinistryCard({ name, icon: Icon, color, link }) {
  const card = (
    <div className={`flex flex-col items-center justify-center p-6 rounded-xl bg-gradient-to-br from-gray-800 to-gray-900 border border-white/10 hover:border-white/20 transition-all duration-300 hover:scale-105 hover:shadow-lg group`}>
      <div className="bg-gradient-to-br from-blue-500 to-blue-600 p-3 rounded-full mb-4 group-hover:scale-110 transition-transform duration-300">
        <Icon className="h-6 w-6 text-white" />
      </div>
      <h3 className="font-medium text-center text-white group-hover:text-blue-400 transition-colors duration-300">{name}</h3>
    </div>
  );

  if (link) {
    return (
      <a 
        href={link}
        target="_blank"
        rel="noopener noreferrer"
        className="block"
      >
        {card}
      </a>
    );
  }
  
  return card;
}