import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function MinistryPage({ title, icon: Icon, color, description, leaders, schedule, events, images }) {
  return (
    <div className="space-y-6">
      <Link to={createPageUrl("Home")}>
        <Button variant="ghost" className="mb-4">
          <ArrowLeft className="w-4 h-4 mr-2" /> Voltar
        </Button>
      </Link>
      
      <Card>
        <CardHeader className={`${color} rounded-t-lg`}>
          <div className="flex items-center gap-3">
            <Icon className="w-8 h-8" />
            <CardTitle className="text-2xl font-bold">{title}</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-2">Sobre o Ministério</h3>
              <p className="text-gray-700">{description}</p>
            </div>
            
            {leaders && leaders.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-2">Líderes</h3>
                <ul className="list-disc list-inside">
                  {leaders.map((leader, index) => (
                    <li key={index} className="text-gray-700">{leader}</li>
                  ))}
                </ul>
              </div>
            )}
            
            {schedule && (
              <div>
                <h3 className="text-lg font-semibold mb-2">Horários</h3>
                <p className="text-gray-700">{schedule}</p>
              </div>
            )}
            
            {events && events.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-2">Próximos Eventos</h3>
                <ul className="space-y-2">
                  {events.map((event, index) => (
                    <li key={index} className="border-l-4 border-blue-500 pl-4 py-1">
                      <p className="font-medium">{event.title}</p>
                      <p className="text-sm text-gray-600">{event.date} - {event.location}</p>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            {images && images.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-2">Galeria</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {images.map((image, index) => (
                    <img 
                      key={index} 
                      src={image} 
                      alt={`${title} - Imagem ${index + 1}`}
                      className="rounded-lg object-cover w-full h-32"
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}