import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, Link as LinkIcon, Play, X, Edit, Trash2 } from "lucide-react";
import { format } from "date-fns";

export default function EventCard({ event, onEdit, onDelete, isAdmin }) {
  const [showVideo, setShowVideo] = useState(false);

  // Helper function to get video thumbnail
  const getVideoThumbnail = (url) => {
    if (!url) return null;
    if (url.includes('youtube.com') || url.includes('youtu.be')) {
      let videoId = '';
      if (url.includes('v=')) {
        videoId = url.split('v=')[1];
        // Remove any additional parameters
        const ampersandPosition = videoId.indexOf('&');
        if (ampersandPosition !== -1) {
          videoId = videoId.substring(0, ampersandPosition);
        }
      } else if (url.includes('youtu.be/')) {
        videoId = url.split('youtu.be/')[1];
      }
      return `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
    }
    return url;
  };

  // Helper function to render video player
  const renderVideoPlayer = (url) => {
    if (!url) return null;
    if (url.includes('youtube.com') || url.includes('youtu.be')) {
      let videoId = '';
      if (url.includes('v=')) {
        videoId = url.split('v=')[1];
        // Remove any additional parameters
        const ampersandPosition = videoId.indexOf('&');
        if (ampersandPosition !== -1) {
          videoId = videoId.substring(0, ampersandPosition);
        }
      } else if (url.includes('youtu.be/')) {
        videoId = url.split('youtu.be/')[1];
      }
      
      return (
        <div className="aspect-video w-full">
          <iframe
            src={`https://www.youtube.com/embed/${videoId}`}
            className="w-full h-full"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
      );
    }
    return (
      <div className="aspect-video w-full">
        <video
          controls
          className="w-full h-full object-contain bg-black"
        >
          <source src={url} type={`video/${event.type || 'mp4'}`} />
          Seu navegador não suporta o elemento de vídeo.
        </video>
      </div>
    );
  };

  return (
    <>
      <Card className="bg-gray-900/90 border border-white/10 hover:border-white/20 transition-all duration-300 h-full flex flex-col">
        <CardHeader className="border-b border-white/10 pb-3">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CardTitle className="text-white">{event.title}</CardTitle>
                {isAdmin && (
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"
                      onClick={(e) => {
                        e.stopPropagation();
                        onEdit(event);
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-red-400 hover:text-red-300 hover:bg-red-400/10"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (window.confirm('Tem certeza que deseja excluir este evento?')) {
                          onDelete(event.id);
                        }
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
              {event.status === "próximo" && (
                <Badge className="bg-blue-600 text-white">Próximo</Badge>
              )}
              {event.status === "em_andamento" && (
                <Badge className="bg-green-600 text-white">Em andamento</Badge>
              )}
              {event.status === "finalizado" && (
                <Badge className="bg-gray-600 text-white">Finalizado</Badge>
              )}
            </div>
            <div className="flex items-center gap-2 mt-2">
              <Calendar className="w-4 h-4 text-white/60" />
              <p className="text-white/60 text-sm">
                {format(new Date(event.date), 'dd/MM/yyyy')}
              </p>
              <Clock className="w-4 h-4 text-white/60 ml-2" />
              <p className="text-white/60 text-sm">{event.time || ''}</p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="py-4 flex-grow">
          <p className="text-white/70 mb-4">{event.description}</p>
          
          <div className="mt-auto space-y-3">
            {event.registration_link && (
              <a 
                href={event.registration_link}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-blue-400 hover:text-blue-300 transition-colors"
              >
                <LinkIcon className="w-4 h-4" />
                <span>Inscrição</span>
              </a>
            )}
            
            {event.video_url && (
              <div className="relative group cursor-pointer" onClick={() => setShowVideo(true)}>
                <div className="relative aspect-video">
                  <img 
                    src={getVideoThumbnail(event.video_url)}
                    alt="Video thumbnail"
                    className="w-full h-full object-cover rounded-lg"
                    onError={(e) => {
                      e.target.onerror = null;
                      e.target.src = "https://via.placeholder.com/640x360?text=Video+n%C3%A3o+dispon%C3%ADvel";
                    }}
                  />
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center group-hover:bg-black/30 transition-all">
                    <div className="bg-white/20 p-4 rounded-full group-hover:bg-white/30 transition-all">
                      <Play className="w-8 h-8 text-white" />
                    </div>
                  </div>
                </div>
                <p className="text-purple-400 hover:text-purple-300 transition-colors mt-2 flex items-center gap-2">
                  <Play className="w-4 h-4" />
                  <span>Assistir vídeo</span>
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {showVideo && (
        <Dialog open={showVideo} onOpenChange={setShowVideo}>
          <DialogContent className="max-w-[95vw] w-[1200px] p-0 bg-gray-900/95 border-white/10 overflow-hidden">
            <DialogHeader className="p-4 absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black/80 to-transparent">
              <DialogTitle className="text-white flex items-center justify-between">
                <span>{event.title}</span>
                <button 
                  onClick={() => setShowVideo(false)}
                  className="text-white/60 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </DialogTitle>
            </DialogHeader>
            <div className="min-h-[50vh] flex items-center justify-center">
              {renderVideoPlayer(event.video_url)}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}