import React, { useState, useEffect } from 'react';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Event } from '@/api/entities';
import { Clock, MapPin, Calendar as CalendarIcon } from 'lucide-react';

export default function EventCalendar() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [eventDates, setEventDates] = useState([]);
  const [eventsOnSelectedDate, setEventsOnSelectedDate] = useState([]);

  useEffect(() => {
    async function fetchEvents() {
      try {
        const allEvents = await Event.list();
        setEvents(allEvents);
        
        // Extract dates for highlighting on calendar
        const dates = allEvents.map(event => new Date(event.date));
        setEventDates(dates);
        
        // Filter events for the initially selected date
        filterEventsForDate(selectedDate, allEvents);
      } catch (error) {
        console.error('Erro ao carregar eventos:', error);
      } finally {
        setLoading(false);
      }
    }
    
    fetchEvents();
  }, []);
  
  useEffect(() => {
    filterEventsForDate(selectedDate, events);
  }, [selectedDate]);
  
  const filterEventsForDate = (date, eventsList) => {
    const dateString = format(date, 'yyyy-MM-dd');
    const filtered = eventsList.filter(event => {
      return format(new Date(event.date), 'yyyy-MM-dd') === dateString;
    });
    setEventsOnSelectedDate(filtered);
  };

  // Function to check if a date has events
  const hasEventOnDate = (date) => {
    return eventDates.some(eventDate => 
      format(eventDate, 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
    );
  };

  return (
    <Card className="bg-gray-900/90 border border-white/10 shadow-lg">
      <CardHeader className="border-b border-white/10">
        <CardTitle className="text-white">Calendário de Eventos</CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={setSelectedDate}
              locale={ptBR}
              className="bg-gray-800/50 rounded-lg p-3 border border-white/10"
              modifiers={{
                hasEvent: eventDates.map(date => new Date(date))
              }}
              modifiersStyles={{
                hasEvent: {
                  backgroundColor: 'rgba(79, 70, 229, 0.2)',
                  fontWeight: 'bold',
                  borderRadius: '50%'
                }
              }}
              styles={{
                day_today: {
                  fontWeight: 'bold',
                  border: '1px solid rgba(255, 255, 255, 0.2)',
                  backgroundColor: 'rgba(255, 255, 255, 0.1)'
                },
                day_selected: {
                  backgroundColor: 'rgb(79, 70, 229)',
                  color: 'white',
                  fontWeight: 'bold'
                }
              }}
            />
          </div>
          
          <div>
            <div className="mb-4">
              <h3 className="text-lg font-medium text-white mb-2 flex items-center">
                <CalendarIcon className="w-4 h-4 mr-2" />
                {format(selectedDate, 'dd/MM/yyyy')}
              </h3>
              <div className="w-10 h-1 bg-indigo-600/50"></div>
            </div>
            
            {loading ? (
              <div className="animate-pulse space-y-3">
                <div className="h-16 bg-gray-800 rounded-md"></div>
                <div className="h-16 bg-gray-800 rounded-md"></div>
              </div>
            ) : eventsOnSelectedDate.length > 0 ? (
              <div className="space-y-4">
                {eventsOnSelectedDate.map(event => (
                  <div 
                    key={event.id}
                    className="p-3 bg-gray-800/50 rounded-lg border border-white/10 hover:border-white/20 transition-all"
                  >
                    <h4 className="font-semibold text-white">{event.title}</h4>
                    <div className="text-white/60 text-sm flex items-center mt-1">
                      <Clock className="w-3 h-3 mr-1" />
                      {event.time}
                    </div>
                    {event.description && (
                      <p className="text-white/70 text-sm mt-2">{event.description}</p>
                    )}
                    <div className="flex gap-4 mt-3">
                      {event.registration_link && (
                        <a 
                          href={event.registration_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-blue-400 hover:text-blue-300"
                        >
                          Inscrição
                        </a>
                      )}
                      {event.video_url && (
                        <a 
                          href={event.video_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-purple-400 hover:text-purple-300"
                        >
                          Vídeo
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-white/60 bg-gray-800/30 rounded-lg border border-white/5">
                Nenhum evento agendado para esta data.
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}